package com.example.mobilapp;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.security.PrivateKey;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Random PRNG;
    private boolean playerIsPlaying;
    private int whereIsPlayer, index;
    private ImageButton playButton, pauseButton, stopButton, nextButton;
    private TextView songTitleTextView;
    private File[] scooterFiles;
    private File directory;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private double accelerationValue, accelerationPreviousValue;
    private String stoppedSongTitle;

    private SensorEventListener sensorEventListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            accelerationValue = Math.sqrt((x * x + y * y + z * z));
            double accelerationChangeValue = Math.abs(accelerationValue - accelerationPreviousValue);
            accelerationPreviousValue = accelerationValue;
            if(accelerationChangeValue >= 10)
            {
                nextSongFunction();
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        player = new MediaPlayer();
        PRNG = new Random();
        playerIsPlaying = true;
        playButton = findViewById(R.id.playButton);
        pauseButton = findViewById(R.id.pauseButton);
        stopButton = findViewById(R.id.stopButton);
        nextButton = findViewById(R.id.nextButton);
        songTitleTextView = findViewById(R.id.songTitleTextView);
        index = 0;
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    MediaPlayer player;

    public void playSomeScooter(View view)
    {
        directory = new File(String.valueOf(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_MUSIC)));
        FilenameFilter filenameFilter = (dir, name) -> name.toLowerCase().contains("scooter");
        scooterFiles = directory.listFiles(filenameFilter);

        try {
            if (player.isPlaying())
                return;
            else if(playerIsPlaying == false) //if paused
            {
                player.seekTo(whereIsPlayer);
                player.start();
                songTitleTextView.setText(stoppedSongTitle);
                playerIsPlaying = true;
                return;
            }

            index = PRNG.nextInt(scooterFiles.length);
            File file = new File(directory, scooterFiles[index].getName());
            songTitleTextView.setText(file.getName());
            player.setDataSource(file.getAbsolutePath());
            player.prepare();
            player.start();
            playerIsPlaying = true;

        } catch (Exception e) {
            Log.e("IOEX", e.getMessage());
        }
    }

    public void pausePlayer(View view)
    {
        if(!player.isPlaying() && view.getId() == pauseButton.getId())
            return;

        if(view.getId() == pauseButton.getId())
        {
            if(playerIsPlaying == true)
            {
                player.pause();
                whereIsPlayer = player.getCurrentPosition();
                playerIsPlaying = false;
            }
        }
        else if(view.getId() == stopButton.getId())
        {
            player.pause();
            whereIsPlayer = 0;
            playerIsPlaying = false;
            stoppedSongTitle = songTitleTextView.getText().toString();
            songTitleTextView.setText("");
        }
    }

    public void nextSong(View view)
    {
        nextSongFunction();
    }

    protected void nextSongFunction()
    {
        try {
            player.reset();
            if(index == scooterFiles.length-1)
                index = 0;

            else
                index++;

            File file = new File(directory, scooterFiles[index].getName());
            player.setDataSource(file.getAbsolutePath());
            songTitleTextView.setText(file.getName());
            player.prepare();
            player.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void onResume()
    {
        super.onResume();
        sensorManager.registerListener(sensorEventListener, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    protected void onPause()
    {
        super.onPause();
        sensorManager.unregisterListener(sensorEventListener);
    }

}